#pragma once
#include "Buffer.h"

struct Point {
    float x, y, z;
    Point(float x, float y, float z) : x(x), y(y), z(z) {}
};

class Rasterizer
{
public:
    static void DrawTriangle(Buffer& buffer, const std::vector<Point>& vertices, unsigned int color1, unsigned int color2, unsigned int color3);

private:
    Buffer& buffer;
    static unsigned int interpolateColor(unsigned int color1, unsigned int color2, unsigned int color3, float b1, float b2, float b3);
};


