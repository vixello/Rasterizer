﻿#include <iostream>
#include <cstdio>
#include <vector>
#include "Rasterizer.h"

int main() {
	Buffer buffer(800, 1200);

    unsigned short header[9] = {
        0x0000, 0x0002, 0x0000, 0x0000, 0x0000, 0x0000,
        0x01000, 0x0100, // width height
        0x0820
    };
    buffer.SetSize(800, 800);
    buffer.ClearColor(0xFF0C6291);
    
    // Define triangle vertices in canonical view volume (-1 to 1 along each axis)
    std::vector<Point> vertices = { Point(0.0f, 0.5f, 0.0f), Point(-0.7f, -0.3f, 0.0f), Point(0.6f, -0.2f, 0.0f) };
    std::vector<Point> vertices2 = { Point(0.0f, 0.5f, 0.0f), Point(-0.9f, 0.6f, 0.0f), Point(-1.3f, -0.3f, 0.0f) };

    //    Color 1: Blue(0xFF0000FF)
    //    Color 2 : Cyan(0xFF00FFFF)
    //    Color 3 : Green(0xFF00FF00)
    //    Color 4 : Pink(0xFFFFC0CB)
    //    Color 5 : Lavender(0xFFE6E6FA)
    //    Color 6 : Mint(0xFF98FB98)
    //    Color 7 : Magenta(0xFFFF00FF)
    //    Color 8 : Lime(0xFF00FF00)
    //    Color 9 : Turquoise(0xFF40E0D0)
    //    Color 10: off-white shade (0xFFFAF3DD)
    Rasterizer::DrawTriangle(buffer, vertices, 0xFFFFC0CB, 0xFF00FFFF, 0xFF98FB98);
    Rasterizer::DrawTriangle(buffer, vertices2, 0xFFA63446, 0xFF000004, 0xFFFF00FF);
    buffer.SaveToTGA("obrazek1.tga", header);

    return 0;

}