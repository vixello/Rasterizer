﻿#include <iostream>
#include <cstdio>
#include <vector>
#include "Rasterizer.h"

int main() {
	Buffer buffer(800, 1200);

    unsigned short header[9] = {
        0x0000, 0x0002, 0x0000, 0x0000, 0x0000, 0x0000,
        0x01000, 0x0100, // width height
        0x0820
    };
    buffer.SetSize(800, 800);
    buffer.ClearColor(0xFF0C6291);
    //buffer.SaveToTGA("obrazek1.tga", header);

    //buffer.SetSize(140, 120);
    //buffer.ClearColor(0xFF25e2f7); 
    //buffer.SaveToTGA("obrazek2.tga", header);
    //000004
    
    // Define triangle vertices in canonical view volume (-1 to 1 along each axis)
    std::vector<Point> vertices = { Point(0.0f, 0.5f, 0.0f), Point(-0.7f, -0.3f, 0.0f), Point(1.0f, -0.7f, 0.0f) };
    std::vector<Point> vertices2 = { Point(0.0f, 0.5f, 0.0f), Point(-0.9f, 0.6f, 0.0f), Point(-0.7f, -0.3f, 0.0f) };

    Rasterizer::DrawTriangle(buffer, vertices, 0xFFFAF3DD);
    Rasterizer::DrawTriangle(buffer, vertices2, 0xFFA63446);
    buffer.SaveToTGA("obrazek1.tga", header);

    return 0;

}