﻿#include "Rasterizer.h"
#include <iostream>


void Rasterizer::DrawTriangle(Buffer& buffer, const std::vector<Point>& vertices, unsigned int color) {
    // Find bounding box of the triangle in screen coordinates
    int minX = 0;
    int maxX = buffer.getWidth() - 1;
    int minY = 0;
    int maxY = buffer.getHeight() - 1;

    // Transform triangle vertices coordinates from canonical to coordinates in rendering window and update bounding box
    // x' = (x + 1) * width/2
    // y' = (y + 1) * height/2

    std::vector<Point> transformedVertices;
    transformedVertices.reserve(vertices.size());
    for (const auto& vertex : vertices) {
        float x = (vertex.x + 1.0f) * (buffer.getWidth() - 1) / 2.0f;
        float y = (1.0f - vertex.y) * (buffer.getHeight() - 1) / 2.0f;

        transformedVertices.emplace_back(x, y, vertex.z);

        // Update bounding box
        minX = std::min(minX, static_cast<int>(x));
        maxX = std::max(maxX, static_cast<int>(x));
        minY = std::min(minY, static_cast<int>(y));
        maxY = std::max(maxY, static_cast<int>(y));
    }

    // Fill the triangle by iterating over bounding box 
    for (int y = minY; y <= maxY; ++y) {
        for (int x = minX; x <= maxX; ++x) {
            // Cases to check if the point is inside triangle
            
            //(X1 - X2) · (Y – Y1) – (Y1 – Y2) · (X – X2) > 0
            float case1 = ((transformedVertices[0].x - transformedVertices[1].x) * (y - transformedVertices[0].y) -
                (transformedVertices[0].y - transformedVertices[1].y) * (x - transformedVertices[0].x)); 
            //(X2 - X3) (Y – Y2) – (Y2 – Y3) ·(X – X2) > 0
            float case2 = ((transformedVertices[1].x - transformedVertices[2].x) * (y - transformedVertices[1].y) -
                (transformedVertices[1].y - transformedVertices[2].y) * (x - transformedVertices[1].x));
            //(X3 - X1) ·(Y – Y3) – (Y3 – Y1) ·(X − X3) > 0 
            float case3 = ((transformedVertices[2].x - transformedVertices[0].x) * (y - transformedVertices[2].y) -
                (transformedVertices[2].y - transformedVertices[0].y) * (x - transformedVertices[2].x));

            // If the point is inside the triangle, set its color
            if (case1 > 0 && case2 > 0 && case3 > 0) {
                buffer.color[y * buffer.getWidth() + x] = color;
            }
        }
    }
}

