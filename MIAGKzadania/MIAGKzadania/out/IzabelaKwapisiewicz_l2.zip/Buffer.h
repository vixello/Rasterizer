#pragma once
#include <vector>


class Buffer {
private:
	std::vector<float> depth;
	int w, h;
	float minx, maxx, miny, maxy, len;

public:
	std::vector<unsigned int> color;
	Buffer(int width, int height);
	int getWidth() { return w; };
	int getHeight() { return h; };

	void SetSize(int width, int height);
	void ClearColor(unsigned int colorToClear);
	void SaveToTGA(const char* filename, unsigned short* header);


};

