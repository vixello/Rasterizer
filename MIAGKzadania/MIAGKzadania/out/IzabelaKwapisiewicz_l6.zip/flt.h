#pragma once

    typedef float flt;

    constexpr flt SmallFloat = 1e-6;
