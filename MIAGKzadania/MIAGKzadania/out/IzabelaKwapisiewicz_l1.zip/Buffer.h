#pragma once
#include <vector>

class Buffer{
private:
	std::vector<unsigned int> color;
	std::vector<float> depth;
	int w, h;
	float minx, maxx, miny, maxy, len;

public:
	Buffer(int width, int height);
	void SetSize(int width, int height);
	void ClearColor(unsigned int colorToClear);
	void SaveToTGA(const char* filename, unsigned short* header);

};

