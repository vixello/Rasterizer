﻿#include <iostream>
#include <cstdio>
#include "Buffer.h"

int main() {
	Buffer buffer(800, 1200);

    unsigned short header[9] = {
        0x0000, 0x0002, 0x0000, 0x0000, 0x0000, 0x0000,
        0x01000, 0x0100, // width height
        0x0820
    };
    buffer.SetSize(800, 1200);
    buffer.ClearColor(0xFF6200ff);
    buffer.SaveToTGA("obrazek1.tga", header);

    //buffer.SetSize(140, 120);
    //buffer.ClearColor(0xFF25e2f7); 
    //buffer.SaveToTGA("obrazek2.tga", header);

}